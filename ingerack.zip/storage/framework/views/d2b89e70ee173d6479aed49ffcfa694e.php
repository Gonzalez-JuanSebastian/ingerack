<!DOCTYPE html>
<html lang="en">

<head>
    <!-- -->    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ingerack SAS</title>

    <!-- css -->   
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/inicio.css')); ?>">

    <!-- fonts -->   
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap" rel="stylesheet">

    <!-- Meta -->   
    <meta name="description" content="Ingerack SAS - Más de 20 años de experiencia en diseño, instalación y mantenimiento de sistemas de refrigeración industrial y climatización. Soluciones energéticamente eficientes y sostenibles.">
    <meta name="keywords" content="refrigeración industrial, aire acondicionado industrial, mantenimiento sistemas de frío, climatización industrial, eficiencia energética, montaje equipos refrigeración, ingeniería en refrigeración,Sistema de refrigeración en valle del cauca, aire acondicionado en valle del cauca, productos de refrigeración en valle del cauca, servicios de refrigeración en valle del cauca, asesoría en sistemas de refrigeración en valles del cauca.">
    <meta name="author" content="Ingerack SAS">
    <meta name="robots" content="index, follow">

    <!-- Icon -->   
    <link rel="icon" href="<?php echo e(asset('img/logo.png')); ?>" type="image/x-icon">

    <!-- Schema.org markup for Google -->
    <script type="application/ld+json">
        {
          "@context": "https://schema.org",
          "@type": "Organization",
          "name": "Ingerack SAS",
          "url": "https://www.ingerack.com",
          "logo": "https://www.ingerack.com/img/logo.png",
          "description": "Empresa especializada en ingeniería de refrigeración industrial y climatización",
          "address": {
            "@type": "PostalAddress",
            "streetAddress": "[Carrera 1H # 60 - 59]",
            "addressLocality": "[Cali]",
            "addressRegion": "[Valle del Cauca]",
            "addressCountry": "CO"
          },
          "contactPoint": {
            "@type": "ContactPoint",
            "telephone": "[+57 316 741 6768]",
            "contactType": "customer service"
          }
        }
    </script>



</head>

<body>
    <header>
        <div class="logo">
            <img src="<?php echo e(asset('img/logo.png')); ?>" alt="Ingerack">
        </div>
        <nav>
            <ul class="nav-links">
                <li><a href="<?php echo e(url('/sobre-nosotros')); ?>">Sobre Nosotros</a></li>
                <li><a href="<?php echo e(url('/servicios')); ?>">Servicios</a></li>
                <li><a href="<?php echo e(url('/contactanos')); ?>">Contactanos</a></li>
                <li><a href="login.html">Iniciar Sesión</a></li>
            </ul>
            <div class="menu-toggle" onclick="toggleMenu()">☰</div>
        </nav>
    </header>


    <div class="hero" id="inicio">
        <div class="cont-info">
            <div class="hero-cont" id="hero-cont">
                <img id="hero-cont-img" src="<?php echo e(asset('img/totallogo.jpeg')); ?>" alt="Ingerack">

                <!-- 
                <div class="hero-bg">
                    <img src="" alt="Ingerack">
            
                    <div class="hero-title">
                        <h1>INGERACK</h1>
                        <h3 id="title-h3">Ingeniería en refrigeración y aire acondicionado</h3>
                        <div class="title-sub">
                            <h3 id="title-sub-h3">FRIO PERFECTO</h3>
                        </div>
                    </div>
                </div>
                 
                    <p>Especialistas en brindar soluciones en Refrigeración industrial</p>                
                -->
            </div>
        </div>

    </div>

    <section class="section" id="sobre-nosotros">
        <div class="container">
            <div class="container-title">
                <h2>¿Estas perdiendo dinero por un frio inadecuado?</h2>
            </div>
            <div class="row">
                <!-- Tarjeta de problemas -->
                <div class="col-12 col-md-6">
                    <div class="card p-4 shadow-sm">
                        <h3 class="text-primary">¿Tu negocio está sufriendo estos síntomas?</h3>
                        <p class="text-danger"><i id="danger" class="fas fa-exclamation-triangle"></i><strong> Tus
                                costos energéticos</strong> están fuera de control.</p>
                        <p class="text-danger"><i id="danger" class="fas fa-exclamation-triangle"></i> Temperaturas
                            fuera del rango te estan generando
                            <strong>perdidas</strong>
                        </p>
                        <p class="text-danger"><i id="danger" class="fas fa-exclamation-triangle"></i> La inocuidad en
                            tus procesos de produccion esta causando
                            <strong>insatisfacción</strong> en tus clientes
                        </p>
                        <br>
                        <p id="problem" class="text-success font-weight-bold">Pero esto no es culpa tuya.</p>
                        <p id="problem">Nadie te ha mostrado <span class="text-success font-weight-bold">cómo
                                cambiarlo.</span></p>
                    </div>
                </div>

                <!-- Tarjeta de soluciones -->
                <div class="col-12 col-md-6">
                    <div class="card p-4 shadow-sm">
                        <h3 class="text-primary">La solución está en un diseño eficiente de refrigeración</h3>
                        <p class="text-success">✅ <strong>Sistemas optimizados</strong> para reducir costos energéticos.
                        </p>
                        <p class="text-success">✅ Tecnología de control inteligente para <strong>mantener las
                                Temperaturas</strong> en el rango adecuado</p>
                        <p class="text-success">✅ Mantenimiento preventivo para <strong>evitar pérdidas y
                                fallos.</strong></p>
                        <br>
                        <p id="solution">Un sistema de refrigeración con <strong>diseño profesional</strong>, reduciras
                            gastos, mejoraras la experiencia de tus clientes y aumentaras la productividad de tus
                            empleados.</p>
                    </div>
                </div>
            </div>
            <div class="container-close">
                <p><strong>!Ingerack frio perfecto tu aliado perfecto¡</strong></p>
            </div>
        </div>

    </section>

    <div class="section-transition0"></div>

    <section class="section" id="servicios">
        <h2>¿En que te podemos ayudar?</h2>
        <p>En <strong>Ingerack S.A.S.</strong> te acompañamos en la toma de decisiones en cada una de tus necesidades 
        </p>
        <div class="services">
            <div class="service-card">
                <div id="service-card-title">
                    <h3>Montaje de sistemas de refrigeración</h3>
                </div>
                <p>Diseño e instalación de sistemas de refrigeración adaptados a sus necesidades específicas para
                    optimizar sus procesos.</p>
            </div>
            <div class="service-card">
                <div id="service-card-title">
                    <h3>Mantenimiento Preventivo y correctivo</h3>
                </div>

                <p>Con un mantenimiento preventivo adecuado se solucionan problemas antes de que los sistemas fallen,
                    garantizando la longevidad de sus equipos, aumentado la productividad en su producción y reduciendo
                    el consumo energético</p>
            </div>
            <div class="service-card">
                <div id="service-card-title">
                    <h3>Sistemas de Ventilación y Climatización </h3>
                </div>

                <p>Con un buen diseño de climatización se garantiza la calidad del aire y el confort térmico aumentando
                    la productividad en sus procesos </p>
            </div>
        </div>
    </section>

    <div class="section-transition2"></div>

    <section class="porque-ingerack-section">
        <div class="container">
            <h2>¿Por qué Escogernos?</h2>
            <p class="intro-text">
                NO solo te entregamos calidad y experiencia, te entregamos COMPROMISO TOTAL, y lo mas importante cumpliras tus expectativas en tu proyecto y recibiras los beneficios y la rentabilidad proyectada, tendras una bonita experiencia.
            </p>
            <div class="reasons-grid">
                <div class="reason-card">
                    <img src="<?php echo e(asset('img/nos2.jpeg')); ?>" alt="Sostenibilidad en refrigeración">
                    <h3>+20 Años de Experiencia</h3>
                </div>
                <div class="reason-card">
                    <img src="<?php echo e(asset('img/elevador.jpeg')); ?>" alt="Sostenibilidad en refrigeración">
                    <h3>Tecnología de Última Generación</h3>
                </div>
                <div class="reason-card">
                    <img src="<?php echo e(asset('img/cuarto.jpeg')); ?>" alt="Sostenibilidad en refrigeración">
                    <h3>Soporte Especializado</h3>
                </div>
            </div>
            <div class="reasons-grid">
                <div class="reason-card">
                    <img src="<?php echo e(asset('img/nos2.jpeg')); ?>" alt="Sostenibilidad en refrigeración">
                    <h3>+20 Años de Experiencia</h3>
                </div>
                <div class="reason-card">
                    <img src="<?php echo e(asset('img/elevador.jpeg')); ?>" alt="Sostenibilidad en refrigeración">
                    <h3>Tecnología de Última Generación</h3>
                </div>
                <div class="reason-card">
                    <img src="<?php echo e(asset('img/cuarto.jpeg')); ?>" alt="Sostenibilidad en refrigeración">
                    <h3>Soporte Especializado</h3>
                </div>
            </div>
        </div>
    </section>

    <svg class="wave-divider2" viewBox="0 0 1440 150" xmlns="http://www.w3.org/2000/svg">
        <path fill="#c8e1eb" fill-opacity="1"
            d="M0,64L80,48C160,32,320,0,480,21.3C640,43,800,117,960,128C1120,139,1280,85,1360,58.7L1440,32V320H0Z">
        </path>
    </svg>

    <section class="experiencia-section">
        <div class="container">
            <div class="content" id="content-experiencia">
                <div class="text">
                    <h2>Máxima Experiencia en Refrigeración Industrial</h2>
                    <p>
                        Con más de dos década de trayectoria, <strong>Ingerack S.A.S.</strong> se ha especializado en el
                        diseño, montaje y mantenimiento de sistemas de refrigeración industrial, donde hemos ayudado a
                        nuestros clientes a aprovechar sus recursos.
                    </p>
                    <p>
                        Trabajamos con <strong>sectores industriales, comerciales y logísticos</strong>, asegurando la
                        conservación óptima de productos perecederos y el cumplimiento de las normativas más exigentes.
                    </p>
                </div>
                <div class="image">
                    <img id="industrial" src="<?php echo e(asset('img/totallogo.jpeg')); ?>"
                        alt="Experiencia en refrigeración industrial">
                </div>
            </div>
        </div>
    </section>

    <section class="sostenibilidad-section">
        <div class="container">
            <div class="content" class="sostenibilidad-cont">
                <div class="image">
                    <img src="<?php echo e(asset('img/nos1.jpeg')); ?>" alt="Sostenibilidad en refrigeración">
                </div>
                <div class="text">
                    <h2>Compromiso con la Sostenibilidad</h2>
                    <p>
                        En <strong>Ingerack</strong> , apostamos por un <strong>futuro más verde</strong>. Nuestros
                        sistemas de refrigeración están diseñados para minimizar el impacto ambiental.
                    </p>
                    <ul class="benefits-list">
                        <li>🌱 <strong>Refrigerantes ecológicos:</strong> Uso de sustancias amigables con el medio
                            ambiente.</li>
                        <li>⚡ <strong>Eficiencia energética:</strong> Disminución del consumo eléctrico hasta un 25%.
                        </li>
                        <li>🔄 <strong>Materiales sostenibles:</strong> Equipos construidos con certificaciones
                            internacionales.
                        </li>
                    </ul>
                    <p>
                        Al elegirnos, no solo obtienes tecnología de punta, sino también una solución responsable con el
                        planeta.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <section class="porque-ingerack-section">
        <div class="container">
            <h2>¿Por qué Escogernos?</h2>
            <p class="intro-text">
                NO solo te entregamos calidad y experiencia, te entregamos COMPROMISO TOTAL, y lo mas importante cumpliras tus expectativas en tu proyecto y recibiras los beneficios y la rentabilidad proyectada, tendras una bonita experiencia.
            </p>
            <div class="reasons-grid">
                <div class="reason-card">
                    <img src="<?php echo e(asset('img/nos2.jpeg')); ?>" alt="Sostenibilidad en refrigeración">
                    <h3>+20 Años de Experiencia</h3>
                </div>
                <div class="reason-card">
                    <img src="<?php echo e(asset('img/elevador.jpeg')); ?>" alt="Sostenibilidad en refrigeración">
                    <h3>Tecnología de Última Generación</h3>
                </div>
                <div class="reason-card">
                    <img src="<?php echo e(asset('img/cuarto.jpeg')); ?>" alt="Sostenibilidad en refrigeración">
                    <h3>Soporte Especializado</h3>
                </div>
            </div>
        </div>
    </section>

    <svg class="wave-divider1" viewBox="0 0 1440 170" xmlns="http://www.w3.org/2000/svg">
        <path fill="#e3f2fd" fill-opacity="1"
            d="M0,64L80,48C160,32,320,0,480,21.3C640,43,800,117,960,128C1120,139,1280,85,1360,58.7L1440,32V320H0Z">
        </path>
    </svg>

    <section id="contacto">
        <div class="contacto-container">
            <div class="contacto-form">
                <h2>Contactanos</h2>
                <form action="<?php echo e(route('contacto.enviar')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="input-group">
                        <label for="nombre">Nombre Completo</label>
                        <input type="text" id="nombre" name="nombre" required placeholder="Escribe tu nombre">
                    </div>

                    <div class="input-group">
                        <label for="email">Correo Electrónico</label>
                        <input type="email" id="email" name="email" required placeholder="ejemplo@email.com">
                    </div>

                    <div class="input-group">
                        <label for="mensaje">Mensaje</label>
                        <textarea id="mensaje" name="mensaje" rows="4" required
                            placeholder="Escribe tu mensaje aquí"></textarea>
                    </div>

                    <button type="submit" class="btn-enviar">Enviar Mensaje</button>
                </form>
            </div>
        </div>
    </section>

    <footer>
        <p>© 2025 Refrigeración Industrial. Todos los derechos reservados.</p>
    </footer>
</body>

</html><?php /**PATH C:\Users\Windows\Desktop\Trabajos\1. Ingerack\web\ingerack\resources\views/inicio.blade.php ENDPATH**/ ?>