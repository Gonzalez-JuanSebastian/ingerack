<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nuevo Mensaje de Contacto</title>
</head>
<body>
    <h2>Nuevo mensaje de contacto</h2>
    <p><strong>Nombre:</strong> <?php echo e($nombre); ?></p>
    <p><strong>Email:</strong> <?php echo e($email); ?></p>
    <p><strong>Mensaje:</strong></p>
    <p><?php echo e($mensaje); ?></p>
</body>
</html>
<?php /**PATH C:\Users\Windows\Desktop\Trabajos\1. Ingerack\web\ingerack\resources\views/emails/contacto.blade.php ENDPATH**/ ?>